import streamlit as st

st.title ("Halaman Penarikan") 
st.image("https://th.bing.com/th/id/OIP.SLvDbrv0SxyyvoUM_UeDnAHaFs?w=237&h=182&c=7&r=0&o=5&dpr=1.5&pid=1.7", caption="Ini Gambar Bank")

